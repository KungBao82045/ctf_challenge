@echo off
title Final Phase of Verification
color 0A

set "SECRET_PASS=s3cre5_kl0n3_n9ddl3r"

echo    =================================================
echo      KungBao Digitale Underverd - AUTENTISERING
echo    =================================================
echo.



echo.
echo                   uu$$$$$$$$$$$uu
echo                uu$$$$$$$$$$$$$$$$$uu
echo               u$$$$$$$$$$$$$$$$$$$$$u
echo              u$$$$$$$$$$$$$$$$$$$$$$$u
echo             u$$$$$$"   "$$$"   "$$$$$$u
echo             "$$$$"      u$u      $$$$"
echo              $$$$u      u$u      u$$$$
echo              $$$$$uu      uu$$$$$$
echo               "$$$$$$$$$$$$$$$$$$$"
echo                 "$$$$$$$$$$$$$$$"
echo                   $$$$"   "$$$$
echo                    $$      $$
echo                     $      $
echo.
echo   [!] ============================================= [!]
echo   [!]          ADVARSEL: SYSTEM KOMPROMITTERT       [!]
echo   [!] ============================================= [!]
echo   [!]  INNBRUDD OPPDAGET  ^|  UAUTORISERT TILGANG    [!]
echo   [!]  SIKKERHETSKLARERING KREVES AV FORSVARSSYSTEM [!]
echo   [!] ============================================= [!]
echo.


set /p "user_input=Skriv passordet her: "

if "%user_input%"=="%SECRET_PASS%" (
    goto ACCESS_GRANTED
) else (
    goto ACCESS_DENIED
)

:ACCESS_DENIED
echo.
echo [!] Ugyldig passord!
pause
exit /b

:ACCESS_GRANTED
echo.
echo [+] Passord er gyldig. Du er en ekte digital kriger!
echo [+] Send den til Jacky: KungBao{hq47_f1l3_cr8ck3d}
pause
exit /b